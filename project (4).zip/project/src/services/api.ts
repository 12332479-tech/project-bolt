
const API_URL = 'http://localhost:5000/api';

export const fetchCars = async () => {
  try {
    const response = await fetch(`${API_URL}/cars`);
    if (!response.ok) {
      throw new Error('Failed to fetch cars');
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching cars:', error);
    throw error;
  }
};

export const fetchCarById = async (id: number) => {
  try {
    const response = await fetch(`${API_URL}/cars/${id}`);
    if (!response.ok) {
        throw new Error('Failed to fetch car');
    }
    return await response.json();
  } catch (error) {
    console.error(`Error fetching car with id ${id}:`, error);
    throw error;
  }
};
